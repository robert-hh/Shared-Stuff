#!/bin/bash

#
# This file is part of the MicroPython project, http://micropython.org/
#
# The MIT License (MIT)
#
# Copyright (c) 2021 Boris Lovosevic 
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
#
echo ""
echo "======================="
echo "RT10XX Firmware flasher"
echo "======================="
echo ""

### Get input firmware file (the 1st argument) ###
FW_FILE="$1"
if [ ! -f "${FW_FILE}" ]; then
    echo "Error: Firmware file not found"
    exit 1
fi
### Determine the firmware file size needed for erase operation ###
FW_SIZE=$(stat -c%s $FW_FILE)
### Specify the used FlashLoader file
FLOADER_BIN=ivt_flashloader.bin
### Loaders communication ports, can be USB HID or UART
FLOADER_COM="-u 0x15A2,0x0073"
### Default RT1050 USB HID pid&vid values ###
BOOT_COM="-u 0x1FC9,0x0130"

### Check presence of FlashLoader on target ###
echo "Check if the FlashLoader exists on target"
if ! ./blhost -t 2000 $FLOADER_COM -j -- get-property 1 0 > /dev/null 2>&1
then
    echo "  FlashLoader not started, checking target ROM bootloader"
    ### Check communication with target bootloader ###
    if ! ./sdphost $BOOT_COM -j -- error-status > /dev/null 2>&1
    then
        # Try with RT1060 USB HID pid&vid values
        BOOT_COM="-u 0x1FC9,0x0135"
        sleep 1
        if ! ./sdphost $BOOT_COM -j -- error-status > /dev/null 2>&1
        then
            echo "    Error: ROM bootloader not found, is you target connected?"
            exit 1
        fi
    fi
    echo "  ROM bootloader detected at $BOOT_COM, upload Flashloader"
    ### Write FlashLoader ###
    if ! ./sdphost $BOOT_COM -j -- write-file 0x20000000 $FLOADER_BIN > /dev/null 2>&1
    then
        echo "  Error uploading FlashLoader"
        exit 1
    fi
    echo "  OK, start Flashloader on target"
    ### Start FlashLoader ###
    if ! ./sdphost $BOOT_COM -j -- jump-address 0x20001000 > /dev/null 2>&1
    then
        echo "    Error starting FlashLoader"
        exit 1
    fi
    echo "  OK, check for Flashloader again"
    sleep 1
    ### Waiting FlashLoader to be initialized for 3 seconds ###
    ### Timeout wait value can be adjusted from Preferences ###
    ### Check presence of FlashLoader ###
    if ! ./blhost -t 2000 $FLOADER_COM -j -- get-property 1 0 > /dev/null 2>&1
    then
        echo "    Error: FlashLoader not detected"
        exit 1
    fi
    echo "  FlashLoader ready"
else
    echo "  FlashLoader already started on target"
fi

echo ""
echo "Flash Firmware file to target"
echo "'${FW_FILE}'"
echo ""
sleep 1

### Configure target memory using options on address 0x2000 ###
echo "  Prepare target memory"
if ! ./blhost -t 5000 $FLOADER_COM -j -- fill-memory 0x2000 4 0xC0000007 word > /dev/null 2>&1
then
    echo "    Error: Configure memory (1)"
    exit 1
fi

if ! ./blhost -t 5000 $FLOADER_COM -j -- fill-memory 0x2004 4 0x00000000 word > /dev/null 2>&1
then
    echo "    Error: Configure memory (2)"
    exit 1
fi

if ! ./blhost -t 5000 $FLOADER_COM -j -- configure-memory 9 0x2000 > /dev/null 2>&1
then
    echo "    Error: Configure memory (3)"
    exit 1
fi

### Erase memory before writing image ###
echo "  Erasing ${FW_SIZE} bytes at 0x60000000"
if ! ./blhost -t 54443 $FLOADER_COM -j -- flash-erase-region 0x60000000 $FW_SIZE 9 > /dev/null 2>&1
then
    echo "    Error: Erase memory memory"
    exit 1
fi

### Use tag 0xF000000F to notify FlashLoader to program FlexSPI NOR config block to the start of device ###
if ! ./blhost -t 5000 $FLOADER_COM -j -- fill-memory 0x3000 4 0xF000000F word > /dev/null 2>&1
then
    echo "    Error: tag"
    exit 1
fi

### Program configuration block ###
#/opt/nxp/MCUX_Provi_v3.1/bin/tools/spsdk/blhost -t 5000 $FLOADER_COM -j -- configure-memory 9 0x3000

### Write image ###
echo "  Write image"
if ! ./blhost -t 5000 $FLOADER_COM -j -- write-memory 0x60000000 ${FW_FILE} 9 > /dev/null 2>&1
then
    echo "    Error: Write image failed"
    exit 1
fi

echo "  Firmware flashed successfully."

