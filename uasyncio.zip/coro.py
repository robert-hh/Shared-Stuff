import uasyncio as asyncio
import sys

brun = True
frun = True
loop = asyncio.get_event_loop()

async def bar():
    global brun
    count = 10
    while count > 0:
        count -= 1
        print("Bar: ", count)
        await asyncio.sleep(1)  # Pause 1s
    brun = False

async def foo():
    global frun
    count = 10
    while count > 0:
        count -= 1
        print("Foo: ", count)
        await asyncio.sleep(2)  # Pause 2s
    frun = False

async def done():
    global brun, frun
    while brun or frun:
        yield
    print ("Done!")
    return

loop.create_task(bar()) # Schedule ASAP
loop.create_task(foo()) # Schedule ASAP
loop.run_until_complete(done())

